#include "stm32f10x.h"                  // Device header
#include "Type_Num.h"
#include "rcc_apb_array.h"

#define	ADC_right_or_Left ADC_DataAlign_Right


/*===========================ADC ͨ�ó�ʼ������===============================*/
void Adc_Init(ADC_TypeDef* Adcx, uint32_t Adc_mode, FunctionalState SC_Mode, FunctionalState CC_Mode, uint32_t TrigConv, uint8_t channel)
{
	uint8_t Adc_APB_Num = Adc_Type_Num(Adcx);
	
    //��ADCʱ��
    RCC_APB2PeriphClockCmd(Adc_APB2_Init_array[Adc_APB_Num], ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);

    //���ýṹ��
    ADC_InitTypeDef ADC_Init_Structure;
    ADC_Init_Structure.ADC_Mode					=	Adc_mode;			
    ADC_Init_Structure.ADC_ScanConvMode			=	SC_Mode;						
    ADC_Init_Structure.ADC_ContinuousConvMode	=	CC_Mode;						
    ADC_Init_Structure.ADC_ExternalTrigConv		=	TrigConv;		
    ADC_Init_Structure.ADC_DataAlign			=	ADC_right_or_Left;
    ADC_Init_Structure.ADC_NbrOfChannel			=	channel;
    ADC_Init(Adcx, &ADC_Init_Structure);
	
    //ʹ��
    ADC_Cmd(Adcx, ENABLE);

	ADC_ResetCalibration(Adcx);
    while(ADC_GetResetCalibrationStatus(Adcx));
    ADC_StartCalibration(Adcx);
    while(ADC_GetCalibrationStatus(Adcx));
}

/*===========================ADC ͨ�����ú���===============================*/
void Adc_Channel_Config(ADC_TypeDef* Adcx, uint8_t ADC_Channel, uint8_t Adc_Order, uint8_t Adc_Cycle)
{
	
    ADC_RegularChannelConfig(Adcx, ADC_Channel, Adc_Order, Adc_Cycle);


}

float Adc_Read(ADC_TypeDef* Adcx)
{
    ADC_SoftwareStartConvCmd(Adcx, ENABLE);						//����������ת��
    while(ADC_GetFlagStatus(Adcx, ADC_FLAG_EOC) == RESET);		//������ת������ʱ����ѭ��
    return ADC_GetConversionValue(Adcx) * 3.3f / 4096.0f;		//ת��Ϊ��ѹ
}
