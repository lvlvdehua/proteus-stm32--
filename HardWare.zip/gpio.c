#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Type_Num.h"
#include "rcc_apb_array.h"

#define None 0


int Key_num = 0;   // �����Ӽ���Ŀ�����
/*=========================================================*/


	


/*===================ͨ�� GPIO ��ʼ������===================*/
void GPIO_INIT(GPIO_TypeDef* GPIO_ABCD, GPIOMode_TypeDef Mode, uint16_t GPIO_Pin_Num, GPIOSpeed_TypeDef Speed)
{
	uint16_t GPIO_RCC_Init_Num = GPIO_Type_Num(GPIO_ABCD);
	
	RCC_APB2PeriphClockCmd(RCC_GPIO_Init_array[GPIO_RCC_Init_Num],ENABLE);
	GPIO_InitTypeDef GPIO_Init_structure;
	
	GPIO_Init_structure.GPIO_Mode = Mode;
	GPIO_Init_structure.GPIO_Pin = GPIO_Pin_Num;
	GPIO_Init_structure.GPIO_Speed = Speed;
	GPIO_Init(GPIO_ABCD, &GPIO_Init_structure);	
}
//



int num_void()
{
	return Key_num;
}

void key_read(void)
{
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
    {
        GPIO_ResetBits(GPIOB, GPIO_Pin_3);   // ���� LED1(�͵�ƽ��)
        while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0);
        GPIO_SetBits(GPIOB, GPIO_Pin_3);     // Ϩ�� LED1
        Key_num++;
    }

    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 1)
    {
        GPIO_SetBits(GPIOB, GPIO_Pin_4);     // ���� LED2(�ߵ�ƽ��)
        while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 1);
        GPIO_ResetBits(GPIOB, GPIO_Pin_4);   // Ϩ�� LED2
        Key_num--;
    }
}
