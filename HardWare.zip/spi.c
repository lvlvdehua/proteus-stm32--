#include "stm32f10x.h"
#include "gpio.h"
#include "timx.h"
#include "Delay.h"
#include "rcc_apb_array.h"
#include "Type_Num.h"


const static uint16_t Spi_Init_pin[][4] = {	{GPIO_Pin_5,	GPIO_Pin_6,		GPIO_Pin_7, 	GPIO_Pin_4},
												{GPIO_Pin_13,	GPIO_Pin_14,	GPIO_Pin_15, 	GPIO_Pin_12}};
static GPIO_TypeDef * Spi_Gpio[3] = {0, GPIOA, GPIOB};

static void(*Spi_Apb1or2[])(uint32_t, FunctionalState) = {0, RCC_APB2PeriphClockCmd, RCC_APB1PeriphClockCmd};
	
void Spix_Init(SPI_TypeDef * Spix)
{
	uint8_t spi_num = Spi_Type_Num(Spix);
    Spi_Apb1or2[spi_num](RCC_Spi_Init_array[spi_num], ENABLE);
    RCC_APB2PeriphClockCmd(RCC_GPIO_Init_array[spi_num], ENABLE);

    GPIO_INIT(Spi_Gpio[spi_num],	GPIO_Mode_AF_PP,			Spi_Init_pin[spi_num][0] | Spi_Init_pin[spi_num][2],	GPIO_Speed_50MHz);
    GPIO_INIT(Spi_Gpio[spi_num],	GPIO_Mode_IN_FLOATING,		Spi_Init_pin[spi_num][1], 								GPIO_Speed_50MHz);
    GPIO_INIT(Spi_Gpio[spi_num],	GPIO_Mode_Out_PP,			Spi_Init_pin[spi_num][3],								GPIO_Speed_50MHz);
    GPIO_SetBits(Spi_Gpio[spi_num], Spi_Init_pin[spi_num][3]);

    SPI_InitTypeDef Spi_Init_Structure;
    Spi_Init_Structure.SPI_Direction			=		SPI_Direction_2Lines_FullDuplex;
    Spi_Init_Structure.SPI_Mode					=		SPI_Mode_Master;
    Spi_Init_Structure.SPI_DataSize				=		SPI_DataSize_8b;
    Spi_Init_Structure.SPI_CPOL					=		SPI_CPOL_Low;
    Spi_Init_Structure.SPI_CPHA					=		SPI_CPHA_1Edge;
    Spi_Init_Structure.SPI_NSS					=		SPI_NSS_Soft;
    Spi_Init_Structure.SPI_BaudRatePrescaler	=		SPI_BaudRatePrescaler_256;
    Spi_Init_Structure.SPI_FirstBit 			=		SPI_FirstBit_MSB;
    Spi_Init_Structure.SPI_CRCPolynomial		=		7;
    SPI_Init(Spix, &Spi_Init_Structure);

    SPI_Cmd(Spix, ENABLE);
}

uint8_t Spi1_ReadSend_Bt(uint8_t TxData)
{
    uint8_t timeout = 0;
    while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET)
    {
        timeout++;
        if(timeout > 200) return 0;
    }
    SPI_I2S_SendData(SPI1, TxData);

    timeout = 0;
    while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET)
    {
        timeout++;
        if(timeout > 200) return 0;
    }
    return SPI_I2S_ReceiveData(SPI1);
}
