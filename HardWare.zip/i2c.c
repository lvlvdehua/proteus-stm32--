#include "stm32f10x.h"                  // Device header
#include  "gpio.h"
#include "rcc_apb_array.h"
#include "Type_Num.h"

#define	I2c_mode				I2C_Mode_I2C
#define	I2c_ack_AbleorEnable	I2C_Ack_Enable
#define	I2c_7b_or_10b			I2C_AcknowledgedAddress_7bit
#define I2c_Duty_2or16_9		I2C_DutyCycle_2
#define I2c_Init_add			0x00

uint16_t I2cx_array[3] = {0, GPIO_Pin_6 | GPIO_Pin_7, GPIO_Pin_10 | GPIO_Pin_11};
 
void I2c_Init(I2C_TypeDef * I2cx, uint32_t I2c_speed)
{
	uint8_t I2c_Num = 0;
	I2c_Num = I2c_Type_Num(I2cx);
	RCC_APB1PeriphClockCmd(RCC_I2C_Init_array[I2c_Num], ENABLE);
	GPIO_INIT(GPIOB, GPIO_Mode_AF_OD, I2cx_array[I2c_Num], GPIO_Speed_50MHz);
	
	I2C_InitTypeDef I2c_Structure;
	I2c_Structure.I2C_ClockSpeed			=	I2c_speed;
	I2c_Structure.I2C_Mode					=	I2c_mode;
	I2c_Structure.I2C_Ack					=	I2c_ack_AbleorEnable;
	I2c_Structure.I2C_AcknowledgedAddress	=	I2c_7b_or_10b;
	
	I2c_Structure.I2C_DutyCycle				=	I2c_Duty_2or16_9;
	I2c_Structure.I2C_OwnAddress1			=	I2c_Init_add;
	
	I2C_Init(I2cx, &I2c_Structure);
	
	I2C_Cmd(I2cx, ENABLE);
}


uint8_t I2c_read(I2C_TypeDef * I2cx, uint8_t I2c_add, uint8_t reg_add)
{
	uint8_t data;
	//������ʼ�ź�
	I2C_GenerateSTART(I2cx, ENABLE);
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_MODE_SELECT) == RESET);
	
	//���ʹӻ���ַ+дλ
	I2C_Send7bitAddress(I2cx, I2c_add, I2C_Direction_Transmitter);		
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == RESET);
	
	//���ͼĴ�����ַ
	I2C_SendData(I2cx, reg_add);
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED) == RESET);
	
	//�ظ���ʼ
	I2C_GenerateSTART(I2cx, ENABLE);
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_MODE_SELECT) == RESET);
	
	//���ʹӻ���ַ+��λ
	I2C_Send7bitAddress(I2cx, I2c_add, I2C_Direction_Receiver);		
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) == RESET);	
	//�ȴ�ACK,�յ����ȡ
	while(I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_BYTE_TRANSMITTING) == RESET);	
	data = I2C_ReadRegister(I2cx, I2C_Register_DR);
	
	I2C_AcknowledgeConfig(I2cx, DISABLE);  //��������NACK
	I2C_GenerateSTOP(I2cx, ENABLE);	//ֹͣ�ź�
	
	return data;
}

void I2c_SendData(I2C_TypeDef * I2cx, uint8_t I2c_add, uint8_t reg_add, uint8_t data)
{
    //������ʼ�ź�
    I2C_GenerateSTART(I2cx, ENABLE);
    while (!I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_MODE_SELECT));

    //���������ַ+дλ
    I2C_Send7bitAddress(I2cx, I2c_add, I2C_Direction_Transmitter);
    while (!I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

    //���ͼĴ�����ַ
    I2C_SendData(I2cx, reg_add);
    while (!I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_BYTE_TRANSMITTING));

    //��������
    I2C_SendData(I2cx, data);
    while (!I2C_CheckEvent(I2cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

    //����ֹͣ�ź�
    I2C_GenerateSTOP(I2cx, ENABLE);
}

