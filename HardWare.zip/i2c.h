#ifndef __i2c_H
#define __i2c_H


void I2c_Init(I2C_TypeDef * I2cx, uint32_t I2c_speed);
uint8_t I2c_read(I2C_TypeDef * I2cx, uint8_t I2c_add, uint8_t reg_add);
void I2c_SendData(I2C_TypeDef * I2cx, uint8_t I2c_add, uint8_t reg_add, uint8_t data);

#endif
