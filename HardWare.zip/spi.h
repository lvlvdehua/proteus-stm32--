#ifndef __spi_H
#define __spi_H



void Spix_Init(SPI_TypeDef * Spix);
uint8_t Spi1_ReadSend_Bt(uint8_t TxData);

#endif
