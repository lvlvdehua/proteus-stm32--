#include "stm32f10x.h"                  // Device header

const uint32_t RCC_GPIO_Init_array[5] = {0, RCC_APB2Periph_GPIOA, RCC_APB2Periph_GPIOB, RCC_APB2Periph_GPIOC, RCC_APB2Periph_GPIOD};
/*GPIOʱ�ӵ�ȫ������*/

const uint32_t RCC_Usart_Init_array[4] = {0, RCC_APB2Periph_USART1, RCC_APB1Periph_USART2,  RCC_APB1Periph_USART3};//ʹ��Usart����ʱ��

const uint32_t Adc_APB2_Init_array[4] = {0, RCC_APB2Periph_ADC1, RCC_APB2Periph_ADC2,  RCC_APB2Periph_ADC3};//ʹ��Usart����ʱ��

const uint32_t RCC_I2C_Init_array[3] = {0, RCC_APB1Periph_I2C1, RCC_APB1Periph_I2C2};

const uint32_t RCC_Spi_Init_array[3] = {0, RCC_APB2Periph_SPI1, RCC_APB1Periph_SPI2};

