#ifndef __Type_Num_H
#define __Type_Num_H

uint8_t Timx_Type_Num(TIM_TypeDef* Timx);

uint32_t GPIO_Type_Num(GPIO_TypeDef* GPIO_ABCD);

uint8_t Usart_Type_Num(USART_TypeDef* Usart_1234);

uint8_t Adc_Type_Num(ADC_TypeDef* Adcx);

uint8_t I2c_Type_Num(I2C_TypeDef * I2x);

uint8_t Spi_Type_Num(SPI_TypeDef * Spix);

#endif
