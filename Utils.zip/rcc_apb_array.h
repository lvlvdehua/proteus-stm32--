#ifndef __rcc_apb_array_H
#define __rcc_apb_array_H

extern uint32_t RCC_GPIO_Init_array[5];
extern uint32_t RCC_Usart_Init_array[4];
extern uint32_t Adc_APB2_Init_array[4];
extern uint32_t RCC_I2C_Init_array[3];
extern uint32_t  RCC_Spi_Init_array[3];

#endif
